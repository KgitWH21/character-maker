(function(root){
'use strict';
const mod=(n,m)=>(n%m+m)%m;
const pick=a=>a[Math.floor(Math.random()*a.length)];
function utc(y,m,d){const x=new Date(0);x.setUTCHours(12,0,0,0);x.setUTCFullYear(y,m-1,d);return x;}
function parseDate(s){if(!/^\d{4}-\d{2}-\d{2}$/.test(s||''))return null;const [y,m,d]=s.split('-').map(Number),x=utc(y,m,d);return y>=1&&y<=9999&&x.getUTCFullYear()===y&&x.getUTCMonth()===m-1&&x.getUTCDate()===d?{y,m,d,date:x}:null;}
function iso(x){return String(x.getUTCFullYear()).padStart(4,'0')+'-'+String(x.getUTCMonth()+1).padStart(2,'0')+'-'+String(x.getUTCDate()).padStart(2,'0');}
function ageAt(birthday,storyYear,storyDate){const b=parseDate(birthday),s=parseDate(storyDate);if(!b)return null;const y=s?s.y:Number(storyYear);if(!Number.isInteger(y)||y<1||y>9999)return null;let age=y-b.y;if(s&&(s.m<b.m||(s.m===b.m&&s.d<b.d)))age--;return age;}
function snapshotBirthday(value){
 const first=String(value??'').split('\n')[0].trim();if(parseDate(first))return first;
 const match=/^([A-Za-z]+) (\d{1,2}), (\d{1,4})$/.exec(first);if(!match)return null;
 const month=['January','February','March','April','May','June','July','August','September','October','November','December'].indexOf(match[1])+1;if(!month)return null;
 const date=match[3].padStart(4,'0')+'-'+String(month).padStart(2,'0')+'-'+match[2].padStart(2,'0');return parseDate(date)?date:null;
}
function guidedBirthday(s){const p=s.guided?.accepted?.identity;return p?.customText===null?p.ingredients?.find(item=>item.fieldId==='birthday'&&parseDate(item.value))?.value||null:null;}
function establishedBirthday(s){const v=s.values?.birthday;if(v?.kept)return (parseDate(v.keptBirthday)?v.keptBirthday:null)||snapshotBirthday(v.keptValue)||guidedBirthday(s)||(parseDate(v.value)?v.value:null);return guidedBirthday(s);}
function formatBirthday(value,settings){const b=parseDate(value),age=ageAt(value,settings.storyYear,settings.storyDate);if(!b)return 'Choose a birth date';const date=new Intl.DateTimeFormat('en',{month:'long',day:'numeric',year:'numeric',timeZone:'UTC'}).format(b.date);return age===null?date:date+'\n'+(age<0?'Not yet born at this story date':settings.storyDate?`Age ${age} on ${settings.storyDate}`:`Turns ${age} in ${settings.storyYear}`);}
function synchronizeBirthday(s){
 const date=establishedBirthday(s),v=s.values?.birthday;if(!date||!v)return s;
 v.value=date;
 if(v.kept&&(parseDate(v.keptBirthday)||snapshotBirthday(v.keptValue)||guidedBirthday(s)))v.keptValue=formatBirthday(date,s.settings);
 // An unaccepted birthday proposal remains editable until the author accepts it.
 for(const p of Object.values(s.guided?.accepted||{}))if(p?.customText===null)for(const item of p.ingredients||[])if(item.fieldId==='birthday')item.value=date;
 return s;
}
function birthForAge(age,storyYear,storyDate){const s=parseDate(storyDate);let y=(s?s.y:Number(storyYear))-age;if(y<1)throw Error('This age range needs an earlier birth year than year 1. Choose a later story year or a younger range.');let m=1+Math.floor(Math.random()*12);let d=1+Math.floor(Math.random()*utc(y,m+1,0).getUTCDate());if(s&&(m>s.m||(m===s.m&&d>s.d)))y--;if(y<1)throw Error('Choose a later story year or a younger age.');d=Math.min(d,utc(y,m+1,0).getUTCDate());return iso(utc(y,m,d));}
const signs=[['Capricorn',120],['Aquarius',219],['Pisces',321],['Aries',420],['Taurus',521],['Gemini',621],['Cancer',723],['Leo',823],['Virgo',923],['Libra',1023],['Scorpio',1122],['Sagittarius',1222]];
function zodiac(m,d){const n=m*100+d;for(const [name,until] of signs)if(n<until)return name;return 'Capricorn';}
const stones=['Garnet','Amethyst','Aquamarine / bloodstone','Diamond','Emerald','Pearl / alexandrite / moonstone','Ruby','Peridot / spinel / sardonyx','Sapphire','Opal / tourmaline','Topaz / citrine','Turquoise / tanzanite / zircon'];
const flowers=['Carnation / snowdrop','Violet / primrose','Daffodil','Daisy / sweet pea','Lily of the valley / hawthorn','Rose / honeysuckle','Larkspur / water lily','Gladiolus / poppy','Aster / morning glory','Marigold / cosmos','Chrysanthemum','Narcissus / holly'];
function birthDetails(s){const b=parseDate(s);if(!b)return null;let chinese='Chinese calendar unavailable in this browser';try{const fmt=new Intl.DateTimeFormat('en-u-ca-chinese',{year:'numeric',month:'numeric',day:'numeric',timeZone:'UTC'});if(fmt.resolvedOptions().calendar==='chinese'){const p=fmt.formatToParts(b.date);const y=Number(p.find(x=>x.type==='relatedYear')?.value);if(Number.isFinite(y)&&y){const animals=['Rat','Ox','Tiger','Rabbit','Dragon','Snake','Horse','Goat','Monkey','Rooster','Dog','Pig'];const stems=['Jia','Yi','Bing','Ding','Wu','Ji','Geng','Xin','Ren','Gui'];const stem=mod(y-4,10);chinese=['Wood','Fire','Earth','Metal','Water'][Math.floor(stem/2)]+' '+animals[mod(y-4,12)]+' · '+(stem%2?'Yin':'Yang')+' ('+stems[stem]+', lunar year '+y+')';}}}catch{}
return {western:zodiac(b.m,b.d),chinese,stone:stones[b.m-1],flower:flowers[b.m-1],weekday:new Intl.DateTimeFormat('en',{weekday:'long',timeZone:'UTC'}).format(b.date)};}
function tarot(card){const reversed=Math.random()<.5;return card.name+' — '+(reversed?'reversed':'upright')+'\n'+(reversed?card.reversed:card.upright)+'\nKeyword: '+card.keyword;}
function definitions(original,extra,traitCount=2){const fields=[];const add=(id,label,group,pool,quick=false,kind='pool')=>fields.push({id,label,group,pool,quick,kind});
add('birthday','Birth date','Identity',null,true,'birthday');add('basic.race','Species / kind','Identity',original.basic.race);add('basic.gender','Gender','Identity',original.basic.gender,true);add('basic.attracted to','Attracted to','Identity',original.basic['attracted to']);add('CHARACTER_NATIONAL_HERITAGE','National heritage / background','Identity',original.CHARACTER_NATIONAL_HERITAGE,true);add('extra.languages','Language','Identity',extra.languages);add('birthplace','Birthplace / setting','Identity',original.background.homeland);add('currentHome','Current home / setting','Identity',original.background.homeland);
add('CHARACTER_NAME_TYPE','Name type / inspiration','Naming',original.CHARACTER_NAME_TYPE,true);add('extra.name_initial','Name starts with','Naming',extra.name_initial,true);add('extra.name_target','Letter applies to','Naming',extra.name_target);add('extra.naming_background','Naming influence','Naming',extra.naming_background);
Object.entries(original.appearance).forEach(([k,v])=>add('appearance.'+k,k.replaceAll('_',' '),'Appearance',k==='distinctive_features'?[...v,...(extra.human_distinctive_features||[])]:v,['height','build','distinctive_features'].includes(k)));
for(let i=0;i<traitCount;i++)add('trait.'+i,'Personality trait '+(i+1),'Personality',original.personality.traits,true);
Object.entries(original.personality).filter(([k])=>k!=='traits').forEach(([k,v])=>add('personality.'+k,k,'Personality',v,['flaws','motivations'].includes(k)));
Object.entries(original.background).forEach(([k,v])=>add('background.'+k,k==='family_status'?'Family connection':k.replaceAll('_',' '),'Background',k==='family_status'?extra.family_connection:v,k==='occupation'));
add('mother','Mother / maternal figure','Background',[...original.parent_status_alive,...original.parent_status_deceased]);add('father','Father / paternal figure','Background',[...original.parent_status_alive,...original.parent_status_deceased]);
add('PRIMARY_TRAUMATIC_EVENT','Primary traumatic event','Formative experiences',original.PRIMARY_TRAUMATIC_EVENT);add('SECONDARY_TRAUMATIC_EVENT','Secondary traumatic event','Formative experiences',original.SECONDARY_TRAUMATIC_EVENT);
['formative_joy','ordinary_influence','unresolved_embarrassment'].forEach(k=>add('extra.'+k,k.replaceAll('_',' '),'Formative experiences',extra[k]));
Object.entries(original.abilities).forEach(([k,v])=>add('abilities.'+k,k.replaceAll('_',' '),'Abilities & equipment',v));Object.entries(original.relationships).forEach(([k,v])=>add('relationships.'+k,k==='organizations'?'Organization / place':k,'Relationships',v));
add('CHARACTER_SPEECH','Voice Sound','Voice Sound',original.CHARACTER_SPEECH);
[['strangers','Around strangers'],['admiration','Around someone they admire'],['family_behavior','Around family'],['lying','When lying'],['embarrassment','When embarrassed'],['happiness','When happy']].forEach(([k,l])=>add('extra.'+k,l,'Voice & behavior',extra[k]));
['contradiction','useless_expertise','collection','specific_dislike','childhood_belief','recurring_dream','signature_possession','tiny_ritual','unexpected_pleasure'].forEach(k=>add('extra.'+k,k.replaceAll('_',' '),'Personal texture',extra[k]));
['birthday_attitude','birthday_tradition','symbolic_belief','superstition','lucky_thing','unlucky_thing'].forEach(k=>add('extra.'+k,k.replaceAll('_',' '),'Birthday & symbolism',extra[k]));
add('birthSymbols','Birthday associations','Birthday & symbolism',null,false,'derived');add('tarot_cards','Tarot card','Tarot & story sparks',original.tarot_cards,false,'tarot');add('tarot_layouts','Tarot character arc','Tarot & story sparks',original.tarot_layouts,false,'arc');add('BASIC_EVENT','Event seed','Tarot & story sparks',original.BASIC_EVENT);add('STORY_DESCRIPTOR','Story descriptor','Tarot & story sparks',original.STORY_DESCRIPTOR);add('SEX_KINK','Adult intimacy','Relationship details',original.SEX_KINK,false,'adult');return fields;}
function speciesValue(original,random=Math.random){const humans=original.basic.race.filter(value=>/^human$/i.test(value)),other=original.basic.race.filter(value=>!/^human$/i.test(value)),draw=random();if(!humans.length)return other[Math.min(other.length-1,Math.floor(draw*other.length))];if(!other.length)return humans[Math.min(humans.length-1,Math.floor(draw*humans.length))];return draw<.9?humans[Math.min(humans.length-1,Math.floor(draw/.9*humans.length))]:other[Math.min(other.length-1,Math.floor((draw-.9)/.1*other.length))];}
function poolValue(f,original){if(f.id==='basic.race')return speciesValue(original);if(f.kind==='tarot')return tarot(pick(f.pool));if(f.kind==='arc'){const layout=pick(f.pool);const remaining=[...original.tarot_cards];return layout.name+'\n'+layout.slots.map(slot=>{const i=Math.floor(Math.random()*remaining.length);return slot+': '+tarot(remaining.splice(i,1)[0]);}).join('\n\n');}return pick(f.pool);}
function originalCount(obj){if(Array.isArray(obj))return obj.length;return Object.values(obj).reduce((s,v)=>s+originalCount(v),0);}
root.CharacterCore={speciesValue,pick,parseDate,iso,utc,ageAt,snapshotBirthday,guidedBirthday,establishedBirthday,formatBirthday,synchronizeBirthday,birthForAge,birthDetails,zodiac,definitions,poolValue,originalCount};
})(typeof window==='undefined'?globalThis:window);
