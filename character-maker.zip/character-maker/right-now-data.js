/* Expand these arrays freely. Original Story Spinner pools are never modified. */
(function(root){
'use strict';
const list=s=>s.split('|');
const pools={
 circumstance:list('Nothing urgent is happening|They arrived earlier than expected|Someone is keeping them waiting|Their clothes are still damp|They have ten minutes to themselves|The lights have just come on|They have misplaced something small|A queue is moving slowly|They are avoiding a puddle|Someone nearby is celebrating|An unfamiliar noise keeps recurring|They have taken a wrong turn|Their usual route is blocked|They are carrying more than is comfortable|They have unexpectedly found a quiet corner|They are sharing the space with a sleeping animal'),
 thought_type:list('Worry|Anticipation|Obligation|Desire|Dread|Curiosity|Recollection|Practical planning'),
 thought_subject:list('An unpaid bill|Lunch|An unanswered invitation|A childhood room|A difficult name|A loose button|Tomorrow’s weather|A promised favor|An unfamiliar neighbor|A strange coincidence|A forgotten password|The last thing someone said|A song they cannot place|A route home|An approaching anniversary|A small mistake at work'),
 thought_form:list('Words|An image|A remembered sound|An imagined conversation|A bodily impression'),
 thought_fragment:list('Did I leave it on?|I could still make it.|One thing at a time.|That sounded different yesterday.|I want something cold.|What was behind that door?|I should write this down.|Not before breakfast.|Their laugh sounded just like hers.|There must be another way there.|Maybe nobody noticed.|I owe them an answer.|Blue tiles, wet shoes.|I wish I had brought the other bag.|What if I simply asked?|This can wait five minutes.'),
 goal:list('Get something to eat|Reach the destination|Finish a small task|Find a misplaced item|Speak to someone|Get some rest|Make a purchase|Leave quietly|Check an unexplained detail|Keep a promise'),
 next_action:list('Look for a sandwich|Check the route|Finish the last paragraph|Search the bag again|Send a short message|Find somewhere to sit|Compare one more price|Collect their coat|Examine the receipt|Call back|Wash a cup|Step outside|Wait a little longer|Ask for directions|Turn the music down|Go back upstairs'),
 next_when:list('Immediately|In two minutes|After this song|When the queue moves|Before lunch|At the next stop|When the other person leaves|In half an hour|Once the rain eases|After finishing the current task'),
 obstacle:list('No obvious obstacle|They may be interrupted|The door may be locked|They lack the right change|They cannot find the address|Someone else needs the same thing|They have very little time|They may change their mind|The signal is unreliable|Their bag is awkward to carry'),
 impulse:list('Stay exactly where they are|Buy a pastry|Go home|Read another chapter|Ignore the message|Take a longer route|Ask an impertinent question|Watch the birds|Take a nap|Call an old friend|Start something entirely different|Keep listening'),
 completed:list('Washed their hands|Sent a routine reply|Counted their change|Missed a call|Tied a shoelace|Finished a glass of water|Returned a borrowed object|Changed seats|Deleted a draft|Fed an animal|Read a notice twice|Carried a box upstairs|Put something back on a shelf|Checked the time|Apologized for bumping into someone|Closed a window'),
 device:list('Wearing a watch|Wearing another tracker|Device off|Battery depleted|No device'),
 sensation:list('Heavy eyelids|Shaky hands|Dry mouth|Feeling energetic|Aching feet|No noticeable discomfort|A cold nose|Warm palms|A stiff shoulder|An itchy sleeve|A rumbling stomach|A light pressure behind the eyes|A comfortable stretch|Damp hair against the neck|A tingling foot|A cool breeze on bare skin|A headache|Something in their teeth|Terrible toothache|Itchy scalp|'),
 freshness:list('Just updated|30 seconds old|3 minutes old|20 minutes old|2 hours old|Outdated — yesterday’s reading'),
 media_format:list('Short-form video|Long-form video|Film|TV episode|Book|Newspaper|Web article|Podcast|Audiobook|Music|Livestream|Social post|Voice message|Advertisement|An incidental overheard or glimpsed source'),
 media_extent:list('Glimpsed|Started|Finished|Abandoned|Reread|Rewatched|Listened twice|Encountered accidentally'),
 media_subject:list('A recipe using leftovers|Local flooding|A lost dog|A space mission|A family reunion|A sporting upset|A murder mystery|Window repairs|An obscure historical dispute|A celebrity apology|A gardening demonstration|An argument about parking|A quiet piano performance|A new train timetable|A language lesson|A product they cannot afford|An amateur ghost story|The migration of birds|A comic misunderstanding|A neighborhood closure|A labor dispute|A tiny handmade model|Someone’s morning routine|A mathematics puzzle'),
 elapsed:list('A minute ago|Ten minutes ago|Half an hour ago|Two hours ago|Earlier today|Yesterday|Three days ago|A week ago|Several weeks ago'),
 effect:list('No noticeable emotional change|Reassured|Frightened|Amused|Irritated|Unexpectedly sad|Curious|Restless|Relieved|Homesick|Hopeful|Embarrassed|Calmer|More alert|Confused|Briefly delighted'),
 lingered:list('A line: “Leave the light on.”|An image of an empty swimming pool|A claim about how memory works|An unanswered question about the ending|A person wearing mismatched gloves|The sound of a spoon tapping glass|A repeated bass note|A map with one road missing|A recipe measurement|The price printed in small type|A dog looking directly at the lens|A pause before an answer|A red door in the background|The phrase “until further notice”'),
 descriptor_media:list('moving|pretentious|ridiculous|useful|tedious|unsettling|beautiful|unconvincing|funny|careful|pointless|absorbing'),
 descriptor_conversation:list('patronizing|warm|hurried|pointless|helpful|awkward|repetitive|honest|guarded|unexpectedly easy'),
 descriptor_location:list('welcoming|cramped|peaceful|oppressive|ordinary|exposed|familiar|confusing|cheerful|impersonal'),
 descriptor_obligation:list('manageable|pointless|daunting|welcome|overdue|routine|promising|inconvenient|necessary|exciting'),
 partner:list('Self / self-talk|Cousin|Friend|Coworker|Parent|Sibling|Partner|Neighbor|Stranger|Customer|Supervisor|Someone they used to know|Roommate|Receptionist|Teacher|A distant relative'),
 method:list('In-person conversation|Phone call|Text exchange|Voice message|Video call|Handwritten note exchange|Online chat|Sign language conversation|Self-talk'),
 conversation_subject:list('What to have for dinner|A shift change|A borrowed charger|A family photograph|A rent increase|Directions|A small achievement|An appointment|A strange dream|A parcel delivery|A broken appliance|A shared memory|Someone’s health, without details|A joke that needed explaining|A request for quiet|Who will pick up the groceries'),
 ending:list('They said goodbye|The practical question was answered|They agreed to talk later|Someone had to leave|The connection dropped|The last message remains unanswered|They laughed and moved on|They changed the subject|Neither knew how to finish|They thanked each other|A timer interrupted|They reached a small agreement'),
 observer:list('A relative|A coworker|A stranger|A shop employee|A surveillance camera|A doorbell camera|A neighbor|A bus driver|A friend|A delivery worker|A librarian|A passing cyclist'),
 sight_location:list('The front doorway|A bus shelter|The corner shop|A stairwell|A shared kitchen|A building lobby|A pedestrian crossing|A library desk|A station entrance|A loading bay|A park bench|An elevator'),
 sight_activity:list('Carrying a paper bag|Waiting by a door|Looking at a phone|Taking off a coat|Walking toward the exit|Reading a sign|Speaking to someone out of frame|Picking up a dropped object|Standing still|Moving a chair|Drinking from a cup|Looking back over one shoulder'),
 recording:list('A witness’s recollection|A handwritten note|A timestamped clip|A blurry still image|A passing mention in conversation|A short incident log'),
 noticed:list('A bright scarf|The bag in their left hand|Mud on their shoes|A repeated glance at the door|Their direction of travel|A visible bandage|An empty cup|An umbrella still folded'),
 missed:list('What was inside the bag|Where they went next|Who they were waiting for|What happened just before|The words being spoken|An object hidden by their coat|Whether anyone followed|The time they first arrived'),
 interpretation:list('They may have been waiting for someone|They seemed in a hurry to the observer|The observer guessed they were lost|The observer assumed they worked there|No interpretation offered|The observer thought they recognized them'),
 reliability:list('Clear view, uncertain timestamp|Partial view|Identity uncertain|Timestamp available|Recollection may be mistaken|Two accounts disagree|No independent confirmation|Brief but unobstructed view'),
 status_type:list('Physical|Emotional|Availability|Intention'),
 stated_status_physical:list('Exhausted.|Fine.|Rested.|Hungry.|Cold.|Need a minute.|My feet hurt.|Wide awake.|A little shaky.|Comfortable.'),
 stated_status_emotional:list('Fine.|Happy.|Worried.|Overwhelmed.|Relieved.|Not ready to talk.|Feeling hopeful.|I’m all right.|Still annoyed.|I miss home.'),
 stated_status_availability:list('Busy.|Don’t call.|Free now.|In a meeting.|Offline for a while.|Can talk after six.|Need a minute.|Do not disturb.|Around if you need me.'),
 stated_status_intention:list('On my way.|Staying in.|Leaving soon.|I’ll call back.|Getting some sleep.|Just checking something.|Heading home.|Taking a break.|I’ll be there.'),
 status_channel:list('In person|A text message|A group chat|A profile status|A handwritten note|A voicemail|A phone call|A public post'),
 audience:list('One friend|A family group|A coworker|Their partner|Anyone viewing their profile|A neighbor|The person beside them|Only themselves'),
 delivery:list('Sincere|Sarcastic|Reassuring|Evasive|Uncertain|Habitual|Understated|Joking|Trying to sound confident'),
 unanswered:list('A routine text asking when they will arrive|An unread group chat|A missed call with no message|A handwritten invitation|A question asked from the next room|An email about a receipt|No unanswered communication|A voice message they have not played|A request they are deliberately postponing'),
 object:list('In hand: a warm mug|In pocket: a crumpled receipt|In bag: a borrowed book|In hand: a loose screw|In pocket: a smooth stone|In bag: spare socks|In hand: an unopened envelope|In pocket: a key on a string|In bag: a bruised apple|In hand: a shopping basket|In pocket: a dead phone|In bag: a tiny wrapped gift'),
 constraint:list('No immediate deadline|The bus leaves in six minutes|A shop closes soon|Someone expects them at noon|The parking meter is nearly out|Food is cooling|A battery is nearly empty|They have promised ten minutes|The laundry cycle is ending|Daylight is fading'),
 interruption:list('A knock at the door|A kettle clicking off|A notification chime|Someone asking for directions|A dropped object|A sudden shower of rain|No recent interruption|A dog barking|An announcement over a speaker|A light going out'),
 attention:list('A flickering light|A half-open door|A familiar voice nearby|A line on a receipt|A bird on the railing|An uncomfortable seam|A message preview|A repeating noise|The smell of toast|The person who keeps checking the clock|A gap in the shelves|A small stain on the table')
};
// Each setting contains [specific spot, matching activities]. Add rows without changing logic.
const locations={
 Home:[['Bathroom',list('In the shower|Brushing teeth|Wiping the mirror')],['Kitchen',list('Eating standing up|Washing a cup|Looking in the refrigerator')],['Bedroom',list('Folding laundry|Looking for a sock|Sitting on the bed')]],
 Work:[['Meeting room',list('Waiting to speak|Arranging papers|Testing a pen')],['Parking garage',list('Changing shoes|Finding the car|Repacking a bag')],['Break room',list('Heating lunch|Rinsing a spoon|Reading a notice')]],
 School:[['Classroom',list('Taking notes|Packing a bag|Waiting for the lesson')],['Hallway',list('Checking a room number|Opening a locker|Waiting for a friend')],['Library corner',list('Reading quietly|Charging a laptop|Searching an index')]],
 Shopping:[['Supermarket aisle',list('Comparing prices|Reading ingredients|Reaching for a tin')],['Checkout queue',list('Counting items|Finding a wallet|Waiting to pay')],['Fitting room',list('Trying a jacket|Checking a seam|Changing shoes')]],
 Traveling:[['Passenger seat',list('Stopped outside the destination|Watching the road|Folding a map')],['Train platform',list('Waiting after a cancellation|Reading the departure board|Moving out of the rain')],['Ferry deck',list('Watching the shore|Holding a hat|Looking for a seat')]],
 Vacation:[['Hotel balcony',list('Watching someone below|Drying a towel|Eating a peach')],['Museum entrance',list('Checking opening hours|Waiting for a ticket|Stowing an umbrella')],['Beach path',list('Shaking sand from shoes|Reading a sign|Walking toward the water')]],
 Outdoors:[['Woodland trail',list('Stepping over a root|Checking a trail marker|Listening to birds')],['Park bench',list('Eating a snack|Resting their feet|Watching a dog')],['Community garden',list('Watering seedlings|Inspecting leaves|Untangling a hose')]],
 'Someone else’s home':[['Guest room',list('Unpacking a bag|Making the bed|Searching for a socket')],['Front porch',list('Waiting to be let in|Removing muddy shoes|Holding a parcel')],['Dining room',list('Setting the table|Passing a bowl|Stacking plates')]],
 'A public facility':[['Swimming pool lobby',list('Finding a locker token|Drying their hair|Reading the schedule')],['Council waiting room',list('Holding a numbered ticket|Filling out a form|Waiting for their name')],['Public restroom',list('Washing hands|Checking a pocket|Drying a sleeve')]]
};
const goalActions={ 'Get something to eat':['Look for a sandwich','Check what is in the kitchen'],'Reach the destination':['Check the route','Ask for directions'],'Finish a small task':['Finish the last paragraph','Check the remaining steps'],'Find a misplaced item':['Search the bag again','Retrace their steps'],'Speak to someone':['Send a short message','Call back'],'Get some rest':['Find somewhere to sit','Go home'],'Make a purchase':['Compare one more price','Join the checkout queue'],'Leave quietly':['Collect their coat','Find the nearest exit'],'Check an unexplained detail':['Examine the receipt','Ask one more question'],'Keep a promise':['Call back','Set a reminder']};
// Availability probabilities, independent of visual focus. Recency and movement are tendencies only.
const archetypes={
 'No preset / unrestricted':{digital:.9,human:.9,device:.75,recent:.5},
 'Off-grid':{digital:.12,human:.8,device:.12,recent:.2},
 'Constantly online':{digital:.98,human:.8,device:.7,recent:.95},
 'Hermit':{digital:.75,human:.15,device:.5,recent:.3},
 'Connected homebody':{digital:.95,human:.35,device:.65,recent:.9,lowMovement:true},
 'Public-facing worker':{digital:.8,human:.98,device:.6,recent:.85},
 'Compartmentalized':{digital:.65,human:.65,device:.6,recent:.5,missing:['Unknown','Unavailable','Conflicting']},
 'Deliberately elusive':{digital:.3,human:.45,device:.4,recent:.3,missing:['Concealed','Conflicting','Unknown']},
 'Temporarily disconnected':{digital:.15,human:.75,device:.2,recent:.2,missing:['Unavailable','Outdated']}
};
root.RightNowData={pools,locations,goalActions,archetypes,informationStates:['No source','Unknown','Unavailable','Outdated','Concealed','Conflicting']};
})(typeof window==='undefined'?globalThis:window);
